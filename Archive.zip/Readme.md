# Final Project- Read Me and User Instructions

## Project Website


## User Instructions
To play the FUT Draft Simulator:

  1. Open this link.
 
  2. Select your 11 players, to compete against 11 random players selected by the computer.
  
  3. Enjoy the game and see whose team has a better rating.
  

  
  Remark:
  - You will not know the ratings of each player beforehand, and will pick the players you think are your favorites or the best.
  -The computer will randomly pick 11 players based on the position and not just the highest rated ones.



